# Board Games Mobile App

Modern board games mobile application built with React Native, Expo, and TypeScript.

## Features

### Games Included

1. **Chess (Satranç)**
   - Single Player (AI with 3 difficulty levels: Easy, Medium, Hard)
   - Local Multiplayer
   - Beautiful chess pieces with smooth animations

2. **Go**
   - Single Player (AI with 3 difficulty levels)
   - Local Multiplayer
   - Traditional 9x9 board
   - Capture mechanics implemented

3. **Shogi (Japanese Chess)**
   - Single Player (AI with 3 difficulty levels)
   - Local Multiplayer
   - Piece promotion system
   - Captured piece drop mechanics

4. **Mancala (Mangala)**
   - Single Player (AI with 3 difficulty levels)
   - Local Multiplayer
   - Traditional stone distribution rules

### Additional Features

- Bilingual support (English/Turkish)
- Responsive design for all screen sizes
- Clean and modern UI
- Smooth animations
- Game state management
- AI opponents with variable difficulty

## Tech Stack

- **Framework:** Expo SDK 54 + React Native
- **Navigation:** Expo Router
- **Language:** TypeScript
- **Styling:** React Native StyleSheet
- **Icons:** Lucide React Native
- **Database:** Supabase (for game saves)

## Getting Started

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Installation

```bash
# Install dependencies
npm install

# Start the development server
npm run dev
```

### Build

```bash
# Build for web
npm run build:web

# Type check
npm run typecheck
```

## Project Structure

```
app/
├── (tabs)/           # Main tab navigation screens
│   ├── chess.tsx     # Chess game screen
│   ├── go.tsx        # Go game screen
│   ├── shogi.tsx     # Shogi game screen
│   └── mancala.tsx   # Mancala game screen
├── _layout.tsx       # Root layout
└── index.tsx         # Entry point

lib/
├── ai.ts             # AI implementations for all games
├── shogi/            # Shogi game logic
└── supabase.ts       # Database client

components/
└── shogi/            # Shogi-specific components
    └── ShogiBoard.tsx

locales/
├── en.json           # English translations
└── tr.json           # Turkish translations

hooks/
├── useLanguage.ts    # Language management hook
├── useGameSave.ts    # Game save/load hook
└── useFrameworkReady.ts
```

## Game Rules

### Chess
- Standard international chess rules
- All special moves supported (castling, en passant, promotion)
- Checkmate detection

### Go
- Traditional Go rules on 9x9 board
- Territory control mechanics
- Stone capture system

### Shogi
- Japanese chess rules on 9x9 board
- Piece promotion in enemy territory
- Captured pieces can be dropped back

### Mancala
- Traditional Mancala/Mangala rules
- Stone distribution mechanics
- Extra turn on landing in store

## AI Difficulty Levels

- **Easy:** Random move selection, perfect for beginners
- **Medium:** Basic strategy evaluation, balanced gameplay
- **Hard:** Advanced move calculation, challenging opponent

## License

MIT License

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.
