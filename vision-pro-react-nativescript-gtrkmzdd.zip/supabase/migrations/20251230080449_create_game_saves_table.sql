/*
  # Create game saves table

  1. New Tables
    - `game_saves`
      - `id` (uuid, primary key) - Unique identifier for each save
      - `game_type` (text) - Type of game (chess, go, shogi, mancala)
      - `board_state` (jsonb) - The board state serialized as JSON
      - `current_player` (text) - Current player
      - `additional_data` (jsonb) - Any additional game-specific data
      - `created_at` (timestamptz) - When the save was created
      - `updated_at` (timestamptz) - When the save was last updated

  2. Security
    - Enable RLS on `game_saves` table
    - Add policy for anyone to read game saves
    - Add policy for anyone to insert game saves
    - Add policy for anyone to update game saves
    - Add policy for anyone to delete game saves

  Note: In a production app, you would want to add authentication and restrict
  access to saves based on user ownership. For this demo, we allow public access.
*/

CREATE TABLE IF NOT EXISTS game_saves (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  player1_id UUID REFERENCES auth.users(id),
  player2_id UUID REFERENCES auth.users(id),
  game_type text NOT NULL CHECK (game_type IN ('chess', 'go', 'shogi', 'mancala')),
  board_state jsonb NOT NULL,
  current_player text NOT NULL,
  additional_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE game_saves ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read game saves"
  ON game_saves
  FOR SELECT
  USING (true);

CREATE POLICY "Anyone can insert game saves"
  ON game_saves
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can update game saves"
  ON game_saves
  FOR UPDATE
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can delete game saves"
  ON game_saves
  FOR DELETE
  USING (true);

CREATE INDEX IF NOT EXISTS idx_game_saves_game_type ON game_saves(game_type);
CREATE INDEX IF NOT EXISTS idx_game_saves_created_at ON game_saves(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_go_games_player1 ON go_games(player1_id);
CREATE INDEX IF NOT EXISTS idx_go_games_player2 ON go_games(player2_id);
CREATE INDEX IF NOT EXISTS idx_go_games_difficulty ON go_games(difficulty);

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_go_games_updated_at
    BEFORE UPDATE ON go_games
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();