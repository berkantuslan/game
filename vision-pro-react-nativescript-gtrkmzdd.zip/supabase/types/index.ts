// supabase/types/index.ts

export interface GoGame {
  id: string;
  player1_id: string | null;
  player2_id: string | null;
  difficulty: 'easy' | 'medium' | 'hard';
  winner: 'black' | 'white' | 'draw';
  moves: Array<{
    row: number;
    col: number;
    color: 'black' | 'white';
  }>;
  created_at: string;
  updated_at: string;
}

export interface GoMove {
  row: number;
  col: number;
  color: 'black' | 'white';
}

export interface GoGameState {
  board: string[][];
  currentTurn: 'black' | 'white';
  blackCaptures: number;
  whiteCaptures: number;
  gameOver: boolean;
}