import { Tabs } from 'expo-router';
import { Trophy, Circle, Swords, Grid2X2 } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: '#2563eb',
        tabBarInactiveTintColor: '#6b7280',
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopWidth: 1,
          borderTopColor: '#e5e7eb',
        },
      }}>
      <Tabs.Screen
        name="chess"
        options={{
          title: 'Chess',
          tabBarIcon: ({ size, color }) => (
            <Trophy size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="go"
        options={{
          title: 'Go',
          tabBarIcon: ({ size, color }) => (
            <Circle size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="shogi"
        options={{
          title: 'Shogi',
          tabBarIcon: ({ size, color }) => (
            <Swords size={size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="mancala"
        options={{
          title: 'Mancala',
          tabBarIcon: ({ size, color }) => (
            <Grid2X2 size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
