import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { useState, useEffect } from 'react';
import { RotateCcw, ArrowLeft } from 'lucide-react-native';
import { useLanguage } from '@/hooks/useLanguage';
import { MancalaAI, type Difficulty } from '@/lib/ai';

const PITS_PER_SIDE = 6;
const INITIAL_STONES = 4;

export default function MancalaScreen() {
  const { t, language, setLanguage } = useLanguage();
  const [gameMode, setGameMode] = useState<'menu' | 'game' | 'difficulty'>('menu');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [board, setBoard] = useState<number[]>(
    Array(14).fill(0).map((_, i) => i === 6 || i === 13 ? 0 : INITIAL_STONES)
  );
  const [currentPlayer, setCurrentPlayer] = useState<1 | 2>(1);
  const [gameOver, setGameOver] = useState(false);
  const [winner, setWinner] = useState<string | null>(null);
  const [isSinglePlayer, setIsSinglePlayer] = useState(false);
  const [isAIThinking, setIsAIThinking] = useState(false);
  const ai = new MancalaAI(difficulty);

  useEffect(() => {
    if (isSinglePlayer && currentPlayer === 2 && gameMode === 'game' && !isAIThinking && !gameOver) {
      makeAIMove();
    }
  }, [currentPlayer, isSinglePlayer, gameMode, gameOver]);

  const makeAIMove = async () => {
    setIsAIThinking(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    const move = ai.getMove(board, 2);
    if (move !== null) {
      handlePitPress(move);
    } else {
      setCurrentPlayer(1);
    }
    setIsAIThinking(false);
  };

  const resetGame = () => {
    setBoard(Array(14).fill(0).map((_, i) => i === 6 || i === 13 ? 0 : INITIAL_STONES));
    setCurrentPlayer(1);
    setGameOver(false);
    setWinner(null);
  };

  const checkGameOver = (newBoard: number[]): boolean => {
    const player1Empty = newBoard.slice(0, 6).every(stones => stones === 0);
    const player2Empty = newBoard.slice(7, 13).every(stones => stones === 0);
    return player1Empty || player2Empty;
  };

  const handlePitPress = (pitIndex: number) => {
    if (gameOver) return;
    if (isSinglePlayer && currentPlayer === 2 && isAIThinking) return;

    if (currentPlayer === 1 && (pitIndex < 0 || pitIndex > 5)) return;
    if (currentPlayer === 2 && (pitIndex < 7 || pitIndex > 12)) return;
    if (board[pitIndex] === 0) return;

    const newBoard = [...board];
    let stones = newBoard[pitIndex];
    newBoard[pitIndex] = 0;

    let currentIndex = pitIndex;

    while (stones > 0) {
      currentIndex = (currentIndex + 1) % 14;

      if (currentPlayer === 1 && currentIndex === 13) continue;
      if (currentPlayer === 2 && currentIndex === 6) continue;

      newBoard[currentIndex]++;
      stones--;
    }

    const landedInStore = (currentPlayer === 1 && currentIndex === 6) ||
                          (currentPlayer === 2 && currentIndex === 13);

    if (!landedInStore) {
      if (newBoard[currentIndex] === 1) {
        if (currentPlayer === 1 && currentIndex >= 0 && currentIndex <= 5) {
          const oppositeIndex = 12 - currentIndex;
          if (newBoard[oppositeIndex] > 0) {
            newBoard[6] += newBoard[currentIndex] + newBoard[oppositeIndex];
            newBoard[currentIndex] = 0;
            newBoard[oppositeIndex] = 0;
          }
        } else if (currentPlayer === 2 && currentIndex >= 7 && currentIndex <= 12) {
          const oppositeIndex = 12 - currentIndex;
          if (newBoard[oppositeIndex] > 0) {
            newBoard[13] += newBoard[currentIndex] + newBoard[oppositeIndex];
            newBoard[currentIndex] = 0;
            newBoard[oppositeIndex] = 0;
          }
        }
      }
      setCurrentPlayer(currentPlayer === 1 ? 2 : 1);
    }

    if (checkGameOver(newBoard)) {
      for (let i = 0; i < 6; i++) {
        newBoard[6] += newBoard[i];
        newBoard[i] = 0;
      }
      for (let i = 7; i < 13; i++) {
        newBoard[13] += newBoard[i];
        newBoard[i] = 0;
      }

      setGameOver(true);
      if (newBoard[6] > newBoard[13]) {
        setWinner(t('common.whitePlayer') + ' ' + t('mancala.wins'));
      } else if (newBoard[13] > newBoard[6]) {
        setWinner(t('common.blackPlayer') + ' ' + t('mancala.wins'));
      } else {
        setWinner(t('mancala.draw'));
      }
    }

    setBoard(newBoard);
  };

  if (gameMode === 'menu') {
    return (
      <View style={styles.menuContainer}>
        <Text style={styles.title}>{t('mancala.title')}</Text>

        <View style={styles.languageToggle}>
          <TouchableOpacity
            style={[styles.langButton, language === 'en' && styles.activeLang]}
            onPress={() => setLanguage('en')}
          >
            <Text style={[styles.langText, language === 'en' && { color: '#fff' }]}>EN</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.langButton, language === 'tr' && styles.activeLang]}
            onPress={() => setLanguage('tr')}
          >
            <Text style={[styles.langText, language === 'tr' && { color: '#fff' }]}>TR</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.modeContainer}>
          <TouchableOpacity
            style={styles.modeButton}
            onPress={() => {
              setIsSinglePlayer(false);
              setGameMode('game');
              resetGame();
            }}
          >
            <Text style={styles.modeButtonText}>{t('common.multiplayer')}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.modeButton}
            onPress={() => setGameMode('difficulty')}
          >
            <Text style={styles.modeButtonText}>{t('common.singlePlayer')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  if (gameMode === 'difficulty') {
    return (
      <View style={styles.difficultyContainer}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setGameMode('menu')}
        >
          <ArrowLeft size={24} color="#2563eb" />
        </TouchableOpacity>

        <Text style={styles.title}>{t('common.difficulty')}</Text>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('easy');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.easy')}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('medium');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.medium')}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('hard');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.hard')}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const screenWidth = Dimensions.get('window').width;
  const pitSize = Math.min((screenWidth - 80) / 7, 50);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setGameMode('menu')}>
          <ArrowLeft size={24} color="#2563eb" />
        </TouchableOpacity>
        <Text style={styles.title}>{t('mancala.title')}</Text>
        <TouchableOpacity onPress={resetGame} style={styles.resetButton}>
          <RotateCcw size={24} color="#2563eb" />
        </TouchableOpacity>
      </View>

      {!gameOver ? (
        <Text style={styles.turnText}>
          {t('common.currentTurn')}: {t('common.' + (currentPlayer === 1 ? 'whitePlayer' : 'blackPlayer'))}
          {isAIThinking && ' (AI)'}
        </Text>
      ) : (
        <Text style={styles.winnerText}>{winner}</Text>
      )}

      <View style={styles.boardContainer}>
        <View style={styles.storeContainer}>
          <View style={[styles.store, { width: pitSize * 1.5, height: pitSize * 3 }]}>
            <Text style={styles.storeText}>{board[13]}</Text>
            <Text style={styles.playerLabel}>{t('mancala.playerLabel')}2</Text>
          </View>
        </View>

        <View style={styles.pitsContainer}>
          <View style={styles.pitsRow}>
            {board.slice(7, 13).reverse().map((stones, index) => (
              <TouchableOpacity
                key={`top-${index}`}
                style={[
                  styles.pit,
                  { width: pitSize, height: pitSize },
                  currentPlayer === 2 && !gameOver && !isAIThinking && styles.activePit,
                ]}
                onPress={() => !isAIThinking && handlePitPress(12 - index)}
                disabled={isAIThinking}
              >
                <Text style={styles.pitText}>{stones}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.pitsRow}>
            {board.slice(0, 6).map((stones, index) => (
              <TouchableOpacity
                key={`bottom-${index}`}
                style={[
                  styles.pit,
                  { width: pitSize, height: pitSize },
                  currentPlayer === 1 && !gameOver && styles.activePit,
                ]}
                onPress={() => handlePitPress(index)}
              >
                <Text style={styles.pitText}>{stones}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.storeContainer}>
          <View style={[styles.store, { width: pitSize * 1.5, height: pitSize * 3 }]}>
            <Text style={styles.storeText}>{board[6]}</Text>
            <Text style={styles.playerLabel}>{t('mancala.playerLabel')}1</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    paddingTop: 60,
  },
  menuContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9fafb',
    paddingHorizontal: 20,
  },
  difficultyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9fafb',
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1f2937',
    textAlign: 'center',
    flex: 1,
  },
  resetButton: {
    padding: 8,
  },
  backButton: {
    position: 'absolute',
    top: 60,
    left: 20,
    zIndex: 10,
    padding: 8,
  },
  turnText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 20,
  },
  winnerText: {
    fontSize: 24,
    fontWeight: '700',
    color: '#059669',
    marginBottom: 20,
  },
  languageToggle: {
    flexDirection: 'row',
    marginBottom: 40,
    gap: 12,
  },
  langButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#e5e7eb',
    borderWidth: 2,
    borderColor: '#d1d5db',
  },
  activeLang: {
    backgroundColor: '#2563eb',
    borderColor: '#2563eb',
  },
  langText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  modeContainer: {
    gap: 16,
    width: '100%',
  },
  modeButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
  },
  modeButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  diffButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
    marginVertical: 12,
    width: '100%',
  },
  diffButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  boardContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#8b4513',
    padding: 20,
    borderRadius: 16,
  },
  storeContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  store: {
    backgroundColor: '#d2691e',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#6b4423',
    marginHorizontal: 10,
  },
  storeText: {
    fontSize: 28,
    fontWeight: '700',
    color: '#fff',
  },
  playerLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
    marginTop: 8,
  },
  pitsContainer: {
    justifyContent: 'center',
  },
  pitsRow: {
    flexDirection: 'row',
    marginVertical: 10,
  },
  pit: {
    backgroundColor: '#d2691e',
    borderRadius: 999,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 4,
    borderWidth: 3,
    borderColor: '#6b4423',
  },
  activePit: {
    borderColor: '#fbbf24',
    borderWidth: 3,
  },
  pitText: {
    fontSize: 20,
    fontWeight: '700',
    color: '#fff',
  },
});
