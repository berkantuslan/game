import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { useState, useEffect } from 'react';
import { RotateCcw, ArrowLeft } from 'lucide-react-native';
import { useLanguage } from '@/hooks/useLanguage';
import { GoAI, type Difficulty } from '@/lib/ai';

type Stone = 'black' | 'white' | null;

const BOARD_SIZE = 9;

export default function GoScreen() {
  const { t, language, setLanguage } = useLanguage();
  const [gameMode, setGameMode] = useState<'menu' | 'game' | 'difficulty'>('menu');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [board, setBoard] = useState<Stone[][]>(
    Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(null))
  );
  const [currentPlayer, setCurrentPlayer] = useState<'black' | 'white'>('black');
  const [capturedStones, setCapturedStones] = useState({ black: 0, white: 0 });
  const [isSinglePlayer, setIsSinglePlayer] = useState(false);
  const [isAIThinking, setIsAIThinking] = useState(false);
  const ai = new GoAI(difficulty);

  useEffect(() => {
    if (isSinglePlayer && currentPlayer === 'white' && gameMode === 'game' && !isAIThinking) {
      makeAIMove();
    }
  }, [currentPlayer, isSinglePlayer, gameMode]);

  const makeAIMove = async () => {
    setIsAIThinking(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    const move = ai.getMove(board as any, 'white');
    if (move) {
      handleIntersectionPress(move[0], move[1]);
    }
    setIsAIThinking(false);
  };

  const resetGame = () => {
    setBoard(Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(null)));
    setCurrentPlayer('black');
    setCapturedStones({ black: 0, white: 0 });
  };

  const getNeighbors = (row: number, col: number): [number, number][] => {
    const neighbors: [number, number][] = [];
    if (row > 0) neighbors.push([row - 1, col]);
    if (row < BOARD_SIZE - 1) neighbors.push([row + 1, col]);
    if (col > 0) neighbors.push([row, col - 1]);
    if (col < BOARD_SIZE - 1) neighbors.push([row, col + 1]);
    return neighbors;
  };

  const getGroup = (board: Stone[][], row: number, col: number, visited: boolean[][]): [number, number][] => {
    if (visited[row][col] || board[row][col] === null) return [];

    visited[row][col] = true;
    const group: [number, number][] = [[row, col]];
    const color = board[row][col];

    for (const [nr, nc] of getNeighbors(row, col)) {
      if (board[nr][nc] === color && !visited[nr][nc]) {
        group.push(...getGroup(board, nr, nc, visited));
      }
    }

    return group;
  };

  const hasLiberties = (board: Stone[][], group: [number, number][]): boolean => {
    for (const [row, col] of group) {
      for (const [nr, nc] of getNeighbors(row, col)) {
        if (board[nr][nc] === null) return true;
      }
    }
    return false;
  };

  const removeGroup = (board: Stone[][], group: [number, number][]): Stone[][] => {
    const newBoard = board.map(row => [...row]);
    for (const [row, col] of group) {
      newBoard[row][col] = null;
    }
    return newBoard;
  };

  const handleIntersectionPress = (row: number, col: number) => {
    if (board[row][col] !== null) return;

    let newBoard = board.map(row => [...row]);
    newBoard[row][col] = currentPlayer;

    const opponent = currentPlayer === 'black' ? 'white' : 'black';
    let capturedCount = 0;

    for (const [nr, nc] of getNeighbors(row, col)) {
      if (newBoard[nr][nc] === opponent) {
        const visited = Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(false));
        const opponentGroup = getGroup(newBoard, nr, nc, visited);

        if (!hasLiberties(newBoard, opponentGroup)) {
          newBoard = removeGroup(newBoard, opponentGroup);
          capturedCount += opponentGroup.length;
        }
      }
    }

    const visited = Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(false));
    const myGroup = getGroup(newBoard, row, col, visited);
    if (!hasLiberties(newBoard, myGroup)) {
      return;
    }

    setBoard(newBoard);
    if (capturedCount > 0) {
      setCapturedStones(prev => ({
        ...prev,
        [currentPlayer]: prev[currentPlayer] + capturedCount,
      }));
    }
    setCurrentPlayer(opponent);
  };

  if (gameMode === 'menu') {
    return (
      <View style={styles.menuContainer}>
        <Text style={styles.title}>{t('go.title')}</Text>

        <View style={styles.languageToggle}>
          <TouchableOpacity
            style={[styles.langButton, language === 'en' && styles.activeLang]}
            onPress={() => setLanguage('en')}
          >
            <Text style={[styles.langText, language === 'en' && { color: '#fff' }]}>EN</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.langButton, language === 'tr' && styles.activeLang]}
            onPress={() => setLanguage('tr')}
          >
            <Text style={[styles.langText, language === 'tr' && { color: '#fff' }]}>TR</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.modeContainer}>
          <TouchableOpacity
            style={styles.modeButton}
            onPress={() => {
              setIsSinglePlayer(false);
              setGameMode('game');
              resetGame();
            }}
          >
            <Text style={styles.modeButtonText}>{t('common.multiplayer')}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.modeButton}
            onPress={() => setGameMode('difficulty')}
          >
            <Text style={styles.modeButtonText}>{t('common.singlePlayer')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  if (gameMode === 'difficulty') {
    return (
      <View style={styles.difficultyContainer}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setGameMode('menu')}
        >
          <ArrowLeft size={24} color="#2563eb" />
        </TouchableOpacity>

        <Text style={styles.title}>{t('common.difficulty')}</Text>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('easy');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.easy')}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('medium');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.medium')}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('hard');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.hard')}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const screenWidth = Dimensions.get('window').width;
  const screenHeight = Dimensions.get('window').height;
  const boardSize = Math.min(screenWidth - 40, screenHeight - 200);
  const cellSize = boardSize / BOARD_SIZE;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setGameMode('menu')}>
          <ArrowLeft size={24} color="#2563eb" />
        </TouchableOpacity>
        <Text style={styles.title}>{t('go.title')}</Text>
        <TouchableOpacity onPress={resetGame} style={styles.resetButton}>
          <RotateCcw size={24} color="#2563eb" />
        </TouchableOpacity>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.turnText}>
          {t('common.currentTurn')}: {currentPlayer === 'black' ? '●' : '○'}
          {isAIThinking && ' (AI)'}
        </Text>
        <Text style={styles.scoreText}>
          {t('go.captured')} - {t('common.blackPlayer')}: {capturedStones.black} | {t('common.whitePlayer')}: {capturedStones.white}
        </Text>
      </View>

      <View style={[styles.board, { width: boardSize, height: boardSize }]}>
        {Array(BOARD_SIZE).fill(0).map((_, row) => (
          <View key={row} style={styles.row}>
            {Array(BOARD_SIZE).fill(0).map((_, col) => (
              <TouchableOpacity
                key={`${row}-${col}`}
                style={[styles.intersection, { width: cellSize, height: cellSize }]}
                onPress={() => !isAIThinking && handleIntersectionPress(row, col)}
                disabled={isAIThinking}
              >
                <View style={styles.lines}>
                  {row < BOARD_SIZE - 1 && <View style={styles.verticalLine} />}
                  {col < BOARD_SIZE - 1 && <View style={styles.horizontalLine} />}
                </View>
                {board[row][col] && (
                  <View style={[
                    styles.stone,
                    { width: cellSize * 0.8, height: cellSize * 0.8 },
                    board[row][col] === 'black' ? styles.blackStone : styles.whiteStone,
                  ]} />
                )}
              </TouchableOpacity>
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    paddingTop: 60,
  },
  menuContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9fafb',
    paddingHorizontal: 20,
  },
  difficultyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9fafb',
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    marginBottom: 12,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1f2937',
    textAlign: 'center',
    flex: 1,
  },
  resetButton: {
    padding: 8,
  },
  backButton: {
    position: 'absolute',
    top: 60,
    left: 20,
    zIndex: 10,
    padding: 8,
  },
  infoContainer: {
    alignItems: 'center',
    marginBottom: 12,
  },
  turnText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 4,
  },
  scoreText: {
    fontSize: 14,
    color: '#6b7280',
  },
  languageToggle: {
    flexDirection: 'row',
    marginBottom: 40,
    gap: 12,
  },
  langButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#e5e7eb',
    borderWidth: 2,
    borderColor: '#d1d5db',
  },
  activeLang: {
    backgroundColor: '#2563eb',
    borderColor: '#2563eb',
  },
  langText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  modeContainer: {
    gap: 16,
    width: '100%',
  },
  modeButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
  },
  modeButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  diffButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
    marginVertical: 12,
    width: '100%',
  },
  diffButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  board: {
    backgroundColor: '#daa520',
    borderRadius: 8,
  },
  row: {
    flexDirection: 'row',
  },
  intersection: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  lines: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  verticalLine: {
    position: 'absolute',
    width: 1,
    height: '100%',
    backgroundColor: '#000',
  },
  horizontalLine: {
    position: 'absolute',
    width: '100%',
    height: 1,
    backgroundColor: '#000',
  },
  stone: {
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#374151',
  },
  blackStone: {
    backgroundColor: '#1f2937',
  },
  whiteStone: {
    backgroundColor: '#f9fafb',
  },
});
