import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { useState, useEffect } from 'react';
import { RotateCcw, ArrowLeft } from 'lucide-react-native';
import { useLanguage } from '@/hooks/useLanguage';
import { ChessAI, type Difficulty } from '@/lib/ai';

type PieceType = 'K' | 'Q' | 'R' | 'B' | 'N' | 'P' | 'k' | 'q' | 'r' | 'b' | 'n' | 'p' | null;

const PIECE_SYMBOLS: Record<string, string> = {
  'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
  'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟',
};

const initialBoard: PieceType[][] = [
  ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
  ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  [null, null, null, null, null, null, null, null],
  ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
  ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
];

export default function ChessScreen() {
  const { t, language, setLanguage } = useLanguage();
  const [gameMode, setGameMode] = useState<'menu' | 'game' | 'difficulty'>('menu');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [board, setBoard] = useState<PieceType[][]>(initialBoard);
  const [selectedSquare, setSelectedSquare] = useState<[number, number] | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<'white' | 'black'>('white');
  const [isSinglePlayer, setIsSinglePlayer] = useState(false);
  const [isAIThinking, setIsAIThinking] = useState(false);
  const ai = new ChessAI(difficulty);

  useEffect(() => {
    if (isSinglePlayer && currentPlayer === 'black' && gameMode === 'game' && !isAIThinking) {
      makeAIMove();
    }
  }, [currentPlayer, isSinglePlayer, gameMode]);

  const makeAIMove = async () => {
    setIsAIThinking(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    const move = ai.getMove(board, 'black');
    if (move) {
      const [fromRow, fromCol] = move.from;
      const [toRow, toCol] = move.to;
      const newBoard = board.map(r => [...r]);
      newBoard[toRow][toCol] = newBoard[fromRow][fromCol];
      newBoard[fromRow][fromCol] = null;
      setBoard(newBoard);
      setCurrentPlayer('white');
    }
    setIsAIThinking(false);
  };

  const resetGame = () => {
    setBoard(initialBoard.map(row => [...row]));
    setSelectedSquare(null);
    setCurrentPlayer('white');
  };

  const isValidMove = (fromRow: number, fromCol: number, toRow: number, toCol: number): boolean => {
    const piece = board[fromRow][fromCol];
    if (!piece) return false;

    const isWhite = piece === piece.toUpperCase();
    if ((currentPlayer === 'white' && !isWhite) || (currentPlayer === 'black' && isWhite)) {
      return false;
    }

    const targetPiece = board[toRow][toCol];
    if (targetPiece && ((isWhite && targetPiece === targetPiece.toUpperCase()) ||
        (!isWhite && targetPiece === targetPiece.toLowerCase()))) {
      return false;
    }

    return true;
  };

  const handleSquarePress = (row: number, col: number) => {
    if (isSinglePlayer && currentPlayer === 'black') return;

    if (selectedSquare) {
      const [fromRow, fromCol] = selectedSquare;
      if (isValidMove(fromRow, fromCol, row, col)) {
        const newBoard = board.map(r => [...r]);
        newBoard[row][col] = newBoard[fromRow][fromCol];
        newBoard[fromRow][fromCol] = null;
        setBoard(newBoard);
        setCurrentPlayer(currentPlayer === 'white' ? 'black' : 'white');
      }
      setSelectedSquare(null);
    } else {
      const piece = board[row][col];
      if (piece) {
        const isWhite = piece === piece.toUpperCase();
        if ((currentPlayer === 'white' && isWhite) || (currentPlayer === 'black' && !isWhite)) {
          setSelectedSquare([row, col]);
        }
      }
    }
  };

  if (gameMode === 'menu') {
    return (
      <View style={styles.menuContainer}>
        <Text style={styles.title}>{t('chess.title')}</Text>

        <View style={styles.languageToggle}>
          <TouchableOpacity
            style={[styles.langButton, language === 'en' && styles.activeLang]}
            onPress={() => setLanguage('en')}
          >
            <Text style={[styles.langText, language === 'en' && { color: '#fff' }]}>EN</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.langButton, language === 'tr' && styles.activeLang]}
            onPress={() => setLanguage('tr')}
          >
            <Text style={[styles.langText, language === 'tr' && { color: '#fff' }]}>TR</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.modeContainer}>
          <TouchableOpacity
            style={styles.modeButton}
            onPress={() => {
              setIsSinglePlayer(false);
              setGameMode('game');
              resetGame();
            }}
          >
            <Text style={styles.modeButtonText}>{t('common.multiplayer')}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.modeButton}
            onPress={() => setGameMode('difficulty')}
          >
            <Text style={styles.modeButtonText}>{t('common.singlePlayer')}</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  if (gameMode === 'difficulty') {
    return (
      <View style={styles.difficultyContainer}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => setGameMode('menu')}
        >
          <ArrowLeft size={24} color="#2563eb" />
        </TouchableOpacity>

        <Text style={styles.title}>{t('common.difficulty')}</Text>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('easy');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.easy')}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('medium');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.medium')}</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.diffButton}
          onPress={() => {
            setDifficulty('hard');
            setIsSinglePlayer(true);
            setGameMode('game');
            resetGame();
          }}
        >
          <Text style={styles.diffButtonText}>{t('common.hard')}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const screenWidth = Dimensions.get('window').width;
  const boardSize = Math.min(screenWidth - 40, 360);
  const squareSize = boardSize / 8;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => setGameMode('menu')}>
          <ArrowLeft size={24} color="#2563eb" />
        </TouchableOpacity>
        <Text style={styles.title}>{t('chess.title')}</Text>
        <TouchableOpacity onPress={resetGame} style={styles.resetButton}>
          <RotateCcw size={24} color="#2563eb" />
        </TouchableOpacity>
      </View>

      <Text style={styles.turnText}>
        {t('common.currentTurn')}: {currentPlayer === 'white' ? t('common.whitePlayer') : t('common.blackPlayer')}
        {isAIThinking && ' (AI)'}
      </Text>

      <View style={[styles.board, { width: boardSize, height: boardSize }]}>
        {board.map((row, rowIndex) => (
          <View key={rowIndex} style={styles.row}>
            {row.map((piece, colIndex) => {
              const isLight = (rowIndex + colIndex) % 2 === 0;
              const isSelected = selectedSquare &&
                selectedSquare[0] === rowIndex &&
                selectedSquare[1] === colIndex;

              return (
                <TouchableOpacity
                  key={`${rowIndex}-${colIndex}`}
                  style={[
                    styles.square,
                    { width: squareSize, height: squareSize },
                    isLight ? styles.lightSquare : styles.darkSquare,
                    isSelected && styles.selectedSquare,
                  ]}
                  onPress={() => handleSquarePress(rowIndex, colIndex)}
                  disabled={isAIThinking}
                >
                  {piece && (
                    <Text style={[styles.piece, { fontSize: squareSize * 0.7 }]}>
                      {PIECE_SYMBOLS[piece]}
                    </Text>
                  )}
                </TouchableOpacity>
              );
            })}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    paddingTop: 60,
  },
  menuContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9fafb',
    paddingHorizontal: 20,
  },
  difficultyContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#f9fafb',
    paddingHorizontal: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    marginBottom: 20,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1f2937',
    textAlign: 'center',
    flex: 1,
  },
  resetButton: {
    padding: 8,
  },
  backButton: {
    position: 'absolute',
    top: 60,
    left: 20,
    zIndex: 10,
    padding: 8,
  },
  turnText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 20,
  },
  languageToggle: {
    flexDirection: 'row',
    marginBottom: 40,
    gap: 12,
  },
  langButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    backgroundColor: '#e5e7eb',
    borderWidth: 2,
    borderColor: '#d1d5db',
  },
  activeLang: {
    backgroundColor: '#2563eb',
    borderColor: '#2563eb',
  },
  langText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
  },
  modeContainer: {
    gap: 16,
    width: '100%',
  },
  modeButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
  },
  modeButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  diffButton: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
    marginVertical: 12,
    width: '100%',
  },
  diffButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  board: {
    borderWidth: 2,
    borderColor: '#374151',
    borderRadius: 8,
    overflow: 'hidden',
  },
  row: {
    flexDirection: 'row',
  },
  square: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  lightSquare: {
    backgroundColor: '#f0d9b5',
  },
  darkSquare: {
    backgroundColor: '#b58863',
  },
  selectedSquare: {
    backgroundColor: '#7fba00',
  },
  piece: {
    fontWeight: '400',
  },
});
