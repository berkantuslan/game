import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Modal } from 'react-native';
import { useLanguage } from '../../hooks/useLanguage';
import ShogiBoard from '../../components/shogi/ShogiBoard';
import ShogiAI from '../../lib/shogi/ShogiAI';
import { ShogiGame } from '../../lib/shogi/ShogiGame';
import { PieceType, Player, Difficulty } from '../../lib/shogi/types';

export default function ShogiScreen() {
  const { t } = useLanguage();
  const [game, setGame] = useState(new ShogiGame());
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [possibleMoves, setPossibleMoves] = useState<string[]>([]);
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [showGuide, setShowGuide] = useState(false);
  const [gameStatus, setGameStatus] = useState<'playing' | 'check' | 'checkmate' | 'stalemate'>('playing');

  useEffect(() => {
    if (game.currentPlayer === 'black' && difficulty !== 'manual') {
      // AI's turn
      setTimeout(() => {
        const ai = new ShogiAI(difficulty);
        const move = ai.getBestMove(game);
        if (move) {
          makeMove(move.from, move.to, move.promote);
        }
      }, 500);
    }
  }, [game.currentPlayer]);

  const handleSquarePress = (square: string) => {
    if (game.currentPlayer === 'black' && difficulty !== 'manual') return;

    if (selectedSquare === square) {
      setSelectedSquare(null);
      setPossibleMoves([]);
    } else if (selectedSquare) {
      // Try to make a move
      const move = possibleMoves.find(m => m === square);
      if (move) {
        const piece = game.getPiece(selectedSquare);
        if (piece && canPromote(piece.type, selectedSquare, square)) {
          // Ask for promotion
          if (confirm(t('shogi.promotePiece'))) {
            makeMove(selectedSquare, square, true);
          } else {
            makeMove(selectedSquare, square, false);
          }
        } else {
          makeMove(selectedSquare, square, false);
        }
      }
      setSelectedSquare(null);
      setPossibleMoves([]);
    } else {
      // Select a piece
      const piece = game.getPiece(square);
      if (piece && piece.player === 'white') {
        setSelectedSquare(square);
        setPossibleMoves(game.getPossibleMoves(square));
      }
    }
  };

  const makeMove = (from: string, to: string, promote: boolean) => {
    const newGame = game.clone();
    newGame.makeMove(from, to, promote);
    setGame(newGame);
    
    // Check game status
    if (newGame.isCheckmate('white')) {
      setGameStatus('checkmate');
    } else if (newGame.isCheck('white')) {
      setGameStatus('check');
    } else if (newGame.isStalemate()) {
      setGameStatus('stalemate');
    } else {
      setGameStatus('playing');
    }
  };

  const canPromote = (pieceType: PieceType, from: string, to: string): boolean => {
    const fromRow = parseInt(from[1]);
    const toRow = parseInt(to[1]);
    return (pieceType === 'pawn' || pieceType === 'lance' || pieceType === 'knight' || 
            pieceType === 'silver' || pieceType === 'rook' || pieceType === 'bishop') &&
           (fromRow <= 3 || toRow <= 3);
  };

  const resetGame = () => {
    setGame(new ShogiGame());
    setSelectedSquare(null);
    setPossibleMoves([]);
    setGameStatus('playing');
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>{t('shogi.title')}</Text>
        <View style={styles.controls}>
          <TouchableOpacity style={styles.button} onPress={() => setShowGuide(true)}>
            <Text style={styles.buttonText}>{t('shogi.howToPlay')}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={resetGame}>
            <Text style={styles.buttonText}>{t('shogi.newGame')}</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.difficultySelector}>
        <Text style={styles.label}>{t('shogi.difficulty')}:</Text>
        {(['easy', 'medium', 'hard', 'manual'] as Difficulty[]).map((level) => (
          <TouchableOpacity
            key={level}
            style={[styles.difficultyButton, difficulty === level && styles.activeDifficulty]}
            onPress={() => setDifficulty(level)}
          >
            <Text style={styles.difficultyText}>{t(`shogi.${level}`)}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {gameStatus !== 'playing' && (
        <View style={styles.statusContainer}>
          <Text style={styles.statusText}>
            {gameStatus === 'checkmate' && t('shogi.checkmate')}
            {gameStatus === 'check' && t('shogi.check')}
            {gameStatus === 'stalemate' && t('shogi.stalemate')}
          </Text>
        </View>
      )}

      <ShogiBoard
        game={game}
        selectedSquare={selectedSquare}
        possibleMoves={possibleMoves}
        onSquarePress={handleSquarePress}
      />

      <Modal visible={showGuide} animationType="slide">
        <ScrollView style={styles.guideContainer}>
          <Text style={styles.guideTitle}>{t('shogi.guideTitle')}</Text>
          
          <View style={styles.guideSection}>
            <Text style={styles.guideSubtitle}>{t('shogi.objective')}</Text>
            <Text style={styles.guideText}>{t('shogi.objectiveText')}</Text>
          </View>

          <View style={styles.guideSection}>
            <Text style={styles.guideSubtitle}>{t('shogi.pieces')}</Text>
            <Text style={styles.guideText}>{t('shogi.piecesText')}</Text>
          </View>

          <View style={styles.guideSection}>
            <Text style={styles.guideSubtitle}>{t('shogi.movement')}</Text>
            <Text style={styles.guideText}>{t('shogi.movementText')}</Text>
          </View>

          <View style={styles.guideSection}>
            <Text style={styles.guideSubtitle}>{t('shogi.promotion')}</Text>
            <Text style={styles.guideText}>{t('shogi.promotionText')}</Text>
          </View>

          <View style={styles.guideSection}>
            <Text style={styles.guideSubtitle}>{t('shogi.dropping')}</Text>
            <Text style={styles.guideText}>{t('shogi.droppingText')}</Text>
          </View>

          <TouchableOpacity style={styles.closeButton} onPress={() => setShowGuide(false)}>
            <Text style={styles.closeButtonText}>{t('common.close')}</Text>
          </TouchableOpacity>
        </ScrollView>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    padding: 20,
    backgroundColor: '#2c3e50',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  controls: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 15,
  },
  button: {
    backgroundColor: '#3498db',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  difficultySelector: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 15,
    backgroundColor: '#ecf0f1',
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginRight: 10,
  },
  difficultyButton: {
    padding: 8,
    marginHorizontal: 5,
    borderRadius: 5,
    backgroundColor: '#bdc3c7',
  },
  activeDifficulty: {
    backgroundColor: '#3498db',
  },
  difficultyText: {
    color: '#2c3e50',
    fontWeight: 'bold',
  },
  statusContainer: {
    backgroundColor: '#e74c3c',
    padding: 10,
    alignItems: 'center',
  },
  statusText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  guideContainer: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  guideTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  guideSection: {
    marginBottom: 20,
  },
  guideSubtitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  guideText: {
    fontSize: 14,
    lineHeight: 20,
  },
  closeButton: {
    backgroundColor: '#3498db',
    padding: 15,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 20,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});