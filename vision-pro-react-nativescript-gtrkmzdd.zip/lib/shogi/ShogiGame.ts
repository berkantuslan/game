import { Player, Piece, PieceType, Move, GameState } from './types';

export class ShogiGame {
  private state: GameState;

  constructor() {
    this.state = this.initializeGame();
  }

  private initializeGame(): GameState {
    const board: Record<string, Piece | null> = {};

    for (let file of ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']) {
      for (let rank of ['1', '2', '3', '4', '5', '6', '7', '8', '9']) {
        board[`${file}${rank}`] = null;
      }
    }

    board['a1'] = { type: 'lance', player: 'white' };
    board['b1'] = { type: 'knight', player: 'white' };
    board['c1'] = { type: 'silver', player: 'white' };
    board['d1'] = { type: 'gold', player: 'white' };
    board['e1'] = { type: 'king', player: 'white' };
    board['f1'] = { type: 'gold', player: 'white' };
    board['g1'] = { type: 'silver', player: 'white' };
    board['h1'] = { type: 'knight', player: 'white' };
    board['i1'] = { type: 'lance', player: 'white' };
    board['b2'] = { type: 'rook', player: 'white' };
    board['h2'] = { type: 'bishop', player: 'white' };
    for (let file of ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']) {
      board[`${file}3`] = { type: 'pawn', player: 'white' };
    }

    board['a9'] = { type: 'lance', player: 'black' };
    board['b9'] = { type: 'knight', player: 'black' };
    board['c9'] = { type: 'silver', player: 'black' };
    board['d9'] = { type: 'gold', player: 'black' };
    board['e9'] = { type: 'king', player: 'black' };
    board['f9'] = { type: 'gold', player: 'black' };
    board['g9'] = { type: 'silver', player: 'black' };
    board['h9'] = { type: 'knight', player: 'black' };
    board['i9'] = { type: 'lance', player: 'black' };
    board['b8'] = { type: 'bishop', player: 'black' };
    board['h8'] = { type: 'rook', player: 'black' };
    for (let file of ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']) {
      board[`${file}7`] = { type: 'pawn', player: 'black' };
    }

    return {
      board,
      currentPlayer: 'white',
      capturedPieces: { white: [], black: [] },
      moveHistory: []
    };
  }

  get board() {
    return this.state.board;
  }

  get currentPlayer() {
    return this.state.currentPlayer;
  }

  getPiece(square: string): Piece | null {
    return this.state.board[square];
  }

  getPossibleMoves(square: string): string[] {
    const piece = this.getPiece(square);
    if (!piece || piece.player !== this.currentPlayer) return [];

    const moves: string[] = [];
    const [file, rank] = square.split('');
    const fileIndex = file.charCodeAt(0) - 'a'.charCodeAt(0);
    const rankIndex = parseInt(rank) - 1;

    switch (piece.type) {
      case 'king':
        this.addKingMoves(moves, fileIndex, rankIndex);
        break;
      case 'rook':
      case 'promotedRook':
        this.addRookMoves(moves, fileIndex, rankIndex);
        break;
      case 'bishop':
      case 'promotedBishop':
        this.addBishopMoves(moves, fileIndex, rankIndex);
        break;
      case 'gold':
      case 'promotedSilver':
      case 'promotedKnight':
      case 'promotedLance':
      case 'promotedPawn':
        this.addGoldMoves(moves, fileIndex, rankIndex, piece.player);
        break;
      case 'silver':
        this.addSilverMoves(moves, fileIndex, rankIndex, piece.player);
        break;
      case 'knight':
        this.addKnightMoves(moves, fileIndex, rankIndex, piece.player);
        break;
      case 'lance':
        this.addLanceMoves(moves, fileIndex, rankIndex, piece.player);
        break;
      case 'pawn':
        this.addPawnMoves(moves, fileIndex, rankIndex, piece.player);
        break;
    }

    return moves.filter(move => this.isValidMove(square, move));
  }

  private addKingMoves(moves: string[], fileIndex: number, rankIndex: number) {
    for (let df = -1; df <= 1; df++) {
      for (let dr = -1; dr <= 1; dr++) {
        if (df === 0 && dr === 0) continue;
        const newFileIndex = fileIndex + df;
        const newRankIndex = rankIndex + dr;
        if (this.isValidSquare(newFileIndex, newRankIndex)) {
          moves.push(`${String.fromCharCode('a'.charCodeAt(0) + newFileIndex)}${newRankIndex + 1}`);
        }
      }
    }
  }

  private addRookMoves(moves: string[], fileIndex: number, rankIndex: number) {
    const directions = [[1, 0], [-1, 0], [0, 1], [0, -1]];
    for (let [df, dr] of directions) {
      let newFileIndex = fileIndex + df;
      let newRankIndex = rankIndex + dr;
      while (this.isValidSquare(newFileIndex, newRankIndex)) {
        const square = `${String.fromCharCode('a'.charCodeAt(0) + newFileIndex)}${newRankIndex + 1}`;
        moves.push(square);
        if (this.getPiece(square)) break;
        newFileIndex += df;
        newRankIndex += dr;
      }
    }
  }

  private addBishopMoves(moves: string[], fileIndex: number, rankIndex: number) {
    const directions = [[1, 1], [1, -1], [-1, 1], [-1, -1]];
    for (let [df, dr] of directions) {
      let newFileIndex = fileIndex + df;
      let newRankIndex = rankIndex + dr;
      while (this.isValidSquare(newFileIndex, newRankIndex)) {
        const square = `${String.fromCharCode('a'.charCodeAt(0) + newFileIndex)}${newRankIndex + 1}`;
        moves.push(square);
        if (this.getPiece(square)) break;
        newFileIndex += df;
        newRankIndex += dr;
      }
    }
  }

  private addGoldMoves(moves: string[], fileIndex: number, rankIndex: number, player: Player) {
    const directions = player === 'white'
      ? [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, 1]]
      : [[1, 0], [-1, 0], [0, 1], [0, -1], [1, -1], [-1, -1]];

    for (let [df, dr] of directions) {
      const newFileIndex = fileIndex + df;
      const newRankIndex = rankIndex + dr;
      if (this.isValidSquare(newFileIndex, newRankIndex)) {
        moves.push(`${String.fromCharCode('a'.charCodeAt(0) + newFileIndex)}${newRankIndex + 1}`);
      }
    }
  }

  private addSilverMoves(moves: string[], fileIndex: number, rankIndex: number, player: Player) {
    const directions = player === 'white'
      ? [[1, 1], [-1, 1], [1, -1], [-1, -1], [0, 1]]
      : [[1, 1], [-1, 1], [1, -1], [-1, -1], [0, -1]];

    for (let [df, dr] of directions) {
      const newFileIndex = fileIndex + df;
      const newRankIndex = rankIndex + dr;
      if (this.isValidSquare(newFileIndex, newRankIndex)) {
        moves.push(`${String.fromCharCode('a'.charCodeAt(0) + newFileIndex)}${newRankIndex + 1}`);
      }
    }
  }

  private addKnightMoves(moves: string[], fileIndex: number, rankIndex: number, player: Player) {
    const knightMoves = player === 'white'
      ? [[2, 1], [2, -1]]
      : [[-2, 1], [-2, -1]];

    for (let [dr, df] of knightMoves) {
      const newFileIndex = fileIndex + df;
      const newRankIndex = rankIndex + dr;
      if (this.isValidSquare(newFileIndex, newRankIndex)) {
        moves.push(`${String.fromCharCode('a'.charCodeAt(0) + newFileIndex)}${newRankIndex + 1}`);
      }
    }
  }

  private addLanceMoves(moves: string[], fileIndex: number, rankIndex: number, player: Player) {
    const direction = player === 'white' ? 1 : -1;
    let newRankIndex = rankIndex + direction;
    while (this.isValidSquare(fileIndex, newRankIndex)) {
      const square = `${String.fromCharCode('a'.charCodeAt(0) + fileIndex)}${newRankIndex + 1}`;
      moves.push(square);
      if (this.getPiece(square)) break;
      newRankIndex += direction;
    }
  }

  private addPawnMoves(moves: string[], fileIndex: number, rankIndex: number, player: Player) {
    const direction = player === 'white' ? 1 : -1;
    const newRankIndex = rankIndex + direction;
    if (this.isValidSquare(fileIndex, newRankIndex)) {
      moves.push(`${String.fromCharCode('a'.charCodeAt(0) + fileIndex)}${newRankIndex + 1}`);
    }
  }

  private isValidSquare(fileIndex: number, rankIndex: number): boolean {
    return fileIndex >= 0 && fileIndex < 9 && rankIndex >= 0 && rankIndex < 9;
  }

  private isValidMove(from: string, to: string): boolean {
    const piece = this.getPiece(from);
    const targetPiece = this.getPiece(to);

    if (!piece) return false;
    if (targetPiece && targetPiece.player === piece.player) return false;

    return true;
  }

  makeMove(from: string, to: string, promote: boolean): void {
    const piece = this.getPiece(from);
    if (!piece) return;

    const capturedPiece = this.getPiece(to);
    if (capturedPiece) {
      this.state.capturedPieces[this.currentPlayer].push(this.demotePiece(capturedPiece));
    }

    this.state.board[to] = piece;
    this.state.board[from] = null;

    if (promote) {
      this.state.board[to] = this.promotePiece(piece);
    }

    this.state.currentPlayer = this.state.currentPlayer === 'white' ? 'black' : 'white';

    this.state.moveHistory.push({
      from,
      to,
      promote,
      piece,
      capturedPiece: capturedPiece || undefined
    });
  }

  private promotePiece(piece: Piece): Piece {
    const promotionMap: Record<PieceType, PieceType> = {
      rook: 'promotedRook',
      bishop: 'promotedBishop',
      silver: 'promotedSilver',
      knight: 'promotedKnight',
      lance: 'promotedLance',
      pawn: 'promotedPawn',
      king: 'king',
      gold: 'gold',
      promotedRook: 'promotedRook',
      promotedBishop: 'promotedBishop',
      promotedSilver: 'promotedSilver',
      promotedKnight: 'promotedKnight',
      promotedLance: 'promotedLance',
      promotedPawn: 'promotedPawn',
    };

    return {
      ...piece,
      type: promotionMap[piece.type] || piece.type
    };
  }

  private demotePiece(piece: Piece): Piece {
    const demotionMap: Record<PieceType, PieceType> = {
      promotedRook: 'rook',
      promotedBishop: 'bishop',
      promotedSilver: 'silver',
      promotedKnight: 'knight',
      promotedLance: 'lance',
      promotedPawn: 'pawn',
      king: 'king',
      gold: 'gold',
      silver: 'silver',
      knight: 'knight',
      lance: 'lance',
      pawn: 'pawn',
      rook: 'rook',
      bishop: 'bishop',
    };

    return {
      ...piece,
      type: demotionMap[piece.type] || piece.type
    };
  }

  getCapturedPieces(player: Player): Piece[] {
    return this.state.capturedPieces[player];
  }

  isCheck(player: Player): boolean {
    return false;
  }

  isCheckmate(player: Player): boolean {
    return false;
  }

  isStalemate(): boolean {
    return false;
  }

  clone(): ShogiGame {
    const cloned = new ShogiGame();
    cloned.state = JSON.parse(JSON.stringify(this.state));
    return cloned;
  }
}
