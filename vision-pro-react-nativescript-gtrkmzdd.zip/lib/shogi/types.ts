export type Player = 'white' | 'black';
export type Difficulty = 'easy' | 'medium' | 'hard' | 'manual';

export interface Piece {
  type: PieceType;
  player: Player;
  hasMoved?: boolean;
}

export type PieceType =
  | 'king'
  | 'rook'
  | 'bishop'
  | 'gold'
  | 'silver'
  | 'knight'
  | 'lance'
  | 'pawn'
  | 'promotedRook'
  | 'promotedBishop'
  | 'promotedSilver'
  | 'promotedKnight'
  | 'promotedLance'
  | 'promotedPawn';

export interface Move {
  from: string;
  to: string;
  promote: boolean;
  piece: Piece;
  capturedPiece?: Piece;
}

export interface GameState {
  board: Record<string, Piece | null>;
  currentPlayer: Player;
  capturedPieces: Record<Player, Piece[]>;
  moveHistory: Move[];
}
