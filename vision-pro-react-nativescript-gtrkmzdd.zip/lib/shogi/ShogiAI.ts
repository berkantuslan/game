import { ShogiGame } from './ShogiGame';
import { Move, Player, Difficulty } from './types';

export default class ShogiAI {
  private difficulty: Difficulty;

  constructor(difficulty: Difficulty) {
    this.difficulty = difficulty;
  }

  getBestMove(game: ShogiGame): Move | null {
    const possibleMoves = this.getAllPossibleMoves(game, 'black');
    if (possibleMoves.length === 0) return null;

    if (this.difficulty === 'easy') {
      return possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
    }

    return possibleMoves[Math.floor(Math.random() * possibleMoves.length)];
  }

  private getAllPossibleMoves(game: ShogiGame, player: Player): Move[] {
    const moves: Move[] = [];

    for (let square in game.board) {
      const piece = game.getPiece(square);
      if (piece && piece.player === player) {
        const possibleMoves = game.getPossibleMoves(square);
        for (let to of possibleMoves) {
          moves.push({
            from: square,
            to,
            promote: false,
            piece
          });
        }
      }
    }

    return moves;
  }
}
