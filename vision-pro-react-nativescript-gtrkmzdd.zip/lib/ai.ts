export type Difficulty = 'easy' | 'medium' | 'hard';

export class GoAI {
  difficulty: Difficulty;

  constructor(difficulty: Difficulty = 'medium') {
    this.difficulty = difficulty;
  }

  getMove(board: (string | null)[][], playerColor: 'black' | 'white'): [number, number] | null {
    const availableMoves = this.getAvailableMoves(board);
    if (availableMoves.length === 0) return null;

    if (this.difficulty === 'easy') {
      return this.getRandomMove(availableMoves);
    } else if (this.difficulty === 'medium') {
      return this.getMediumMove(board, availableMoves, playerColor);
    } else {
      return this.getHardMove(board, availableMoves, playerColor);
    }
  }

  private getAvailableMoves(board: (string | null)[][]): [number, number][] {
    const moves: [number, number][] = [];
    for (let row = 0; row < board.length; row++) {
      for (let col = 0; col < board[row].length; col++) {
        if (board[row][col] === null) {
          moves.push([row, col]);
        }
      }
    }
    return moves;
  }

  private getRandomMove(moves: [number, number][]): [number, number] {
    return moves[Math.floor(Math.random() * moves.length)];
  }

  private getMediumMove(
    board: (string | null)[][],
    moves: [number, number][],
    playerColor: 'black' | 'white'
  ): [number, number] {
    const corners = this.getCornerMoves(moves);
    if (corners.length > 0 && Math.random() > 0.5) {
      return this.getRandomMove(corners);
    }
    return this.getRandomMove(moves);
  }

  private getHardMove(
    board: (string | null)[][],
    moves: [number, number][],
    playerColor: 'black' | 'white'
  ): [number, number] {
    const centerMoves = this.getCenterMoves(board, moves);
    const strategicMoves = centerMoves.length > 0 ? centerMoves : moves;
    return this.getRandomMove(strategicMoves);
  }

  private getCornerMoves(moves: [number, number][]): [number, number][] {
    return moves.filter(([row, col]) => (row < 2 || row > 6) && (col < 2 || col > 6));
  }

  private getCenterMoves(board: (string | null)[][], moves: [number, number][]): [number, number][] {
    const size = board.length;
    const center = size / 2;
    return moves.filter(([row, col]) => {
      const distance = Math.sqrt(Math.pow(row - center, 2) + Math.pow(col - center, 2));
      return distance < center * 0.7;
    });
  }
}

export class ChessAI {
  difficulty: Difficulty;

  constructor(difficulty: Difficulty = 'medium') {
    this.difficulty = difficulty;
  }

  getMove(
    board: (string | null)[][],
    playerColor: 'white' | 'black'
  ): { from: [number, number]; to: [number, number] } | null {
    const moves = this.getValidMoves(board, playerColor);
    if (moves.length === 0) return null;

    if (this.difficulty === 'easy') {
      return moves[Math.floor(Math.random() * moves.length)];
    } else if (this.difficulty === 'medium') {
      return this.evaluateMedium(moves, board);
    } else {
      return this.evaluateHard(moves, board, playerColor);
    }
  }

  private getValidMoves(
    board: (string | null)[][],
    playerColor: 'white' | 'black'
  ): Array<{ from: [number, number]; to: [number, number] }> {
    const moves: Array<{ from: [number, number]; to: [number, number] }> = [];
    const isWhite = playerColor === 'white';

    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = board[row][col];
        if (!piece) continue;
        if ((isWhite && piece === piece.toLowerCase()) || (!isWhite && piece === piece.toUpperCase())) continue;

        for (let toRow = 0; toRow < 8; toRow++) {
          for (let toCol = 0; toCol < 8; toCol++) {
            if (row === toRow && col === toCol) continue;
            const target = board[toRow][toCol];
            if (target && ((isWhite && target === target.toUpperCase()) || (!isWhite && target === target.toLowerCase()))) {
              continue;
            }
            moves.push({ from: [row, col], to: [toRow, toCol] });
          }
        }
      }
    }

    return moves;
  }

  private evaluateMedium(
    moves: Array<{ from: [number, number]; to: [number, number] }>,
    board: (string | null)[][]
  ): { from: [number, number]; to: [number, number] } {
    const capturingMoves = moves.filter(move => board[move.to[0]][move.to[1]] !== null);
    if (capturingMoves.length > 0 && Math.random() > 0.4) {
      return capturingMoves[Math.floor(Math.random() * capturingMoves.length)];
    }
    return moves[Math.floor(Math.random() * moves.length)];
  }

  private evaluateHard(
    moves: Array<{ from: [number, number]; to: [number, number] }>,
    board: (string | null)[][],
    playerColor: 'white' | 'black'
  ): { from: [number, number]; to: [number, number] } {
    let bestMove = moves[0];
    let bestScore = -999;

    for (const move of moves) {
      let score = 0;
      const target = board[move.to[0]][move.to[1]];

      if (target) {
        score += this.getPieceValue(target);
      }

      const centerDistance = Math.abs(move.to[0] - 3.5) + Math.abs(move.to[1] - 3.5);
      score -= centerDistance * 0.1;

      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }

    return bestMove;
  }

  private getPieceValue(piece: string): number {
    const upperPiece = piece.toUpperCase();
    switch (upperPiece) {
      case 'Q': return 9;
      case 'R': return 5;
      case 'B': return 3;
      case 'N': return 3;
      case 'P': return 1;
      default: return 0;
    }
  }
}

export class ShogiAI {
  difficulty: Difficulty;

  constructor(difficulty: Difficulty = 'medium') {
    this.difficulty = difficulty;
  }

  getMove(
    board: (string | null)[][],
    playerColor: 'white' | 'black'
  ): { from: [number, number]; to: [number, number] } | null {
    const moves = this.getValidMoves(board, playerColor);
    if (moves.length === 0) return null;

    if (this.difficulty === 'easy') {
      return moves[Math.floor(Math.random() * moves.length)];
    }
    return moves[Math.floor(Math.random() * moves.length)];
  }

  private getValidMoves(
    board: (string | null)[][],
    playerColor: 'white' | 'black'
  ): Array<{ from: [number, number]; to: [number, number] }> {
    const moves: Array<{ from: [number, number]; to: [number, number] }> = [];
    const isUpperCase = playerColor === 'white';

    for (let row = 0; row < 9; row++) {
      for (let col = 0; col < 9; col++) {
        const piece = board[row][col];
        if (!piece) continue;
        if ((isUpperCase && piece === piece.toLowerCase()) || (!isUpperCase && piece === piece.toUpperCase())) continue;

        for (let toRow = 0; toRow < 9; toRow++) {
          for (let toCol = 0; toCol < 9; toCol++) {
            if (row === toRow && col === toCol) continue;
            const target = board[toRow][toCol];
            if (target && ((isUpperCase && target === target.toUpperCase()) || (!isUpperCase && target === target.toLowerCase()))) {
              continue;
            }
            moves.push({ from: [row, col], to: [toRow, toCol] });
          }
        }
      }
    }

    return moves;
  }
}

export class MancalaAI {
  difficulty: Difficulty;

  constructor(difficulty: Difficulty = 'medium') {
    this.difficulty = difficulty;
  }

  getMove(board: number[], playerNumber: 1 | 2): number | null {
    const pits = playerNumber === 1 ? [0, 1, 2, 3, 4, 5] : [7, 8, 9, 10, 11, 12];
    const validMoves = pits.filter(pit => board[pit] > 0);

    if (validMoves.length === 0) return null;

    if (this.difficulty === 'easy') {
      return validMoves[Math.floor(Math.random() * validMoves.length)];
    } else if (this.difficulty === 'medium') {
      const nonEmptyMoves = validMoves.filter(pit => board[pit] >= 2);
      return nonEmptyMoves.length > 0 ? nonEmptyMoves[0] : validMoves[0];
    } else {
      return this.getStrategicMove(board, playerNumber, validMoves);
    }
  }

  private getStrategicMove(board: number[], playerNumber: 1 | 2, validMoves: number[]): number {
    let bestPit = validMoves[0];
    let bestScore = -999;

    for (const pit of validMoves) {
      const storeIndex = playerNumber === 1 ? 6 : 13;
      const landIndex = (pit + board[pit]) % 14;
      let score = board[pit];

      if (landIndex === storeIndex) {
        score += 10;
      }

      if (score > bestScore) {
        bestScore = score;
        bestPit = pit;
      }
    }

    return bestPit;
  }
}
