import { useState, useEffect } from 'react';
import enTranslations from '../locales/en.json';
import trTranslations from '../locales/tr.json';

type Language = 'en' | 'tr';

const translations = {
  en: enTranslations,
  tr: trTranslations,
};

export function useLanguage() {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLanguage = localStorage?.getItem('app-language') as Language;
    if (savedLanguage && (savedLanguage === 'en' || savedLanguage === 'tr')) {
      setLanguage(savedLanguage);
    }
  }, []);

  const setLang = (lang: Language) => {
    setLanguage(lang);
    try {
      localStorage?.setItem('app-language', lang);
    } catch {}
  };

  const t = (key: string): string => {
    const keys = key.split('.');
    let value: any = translations[language];

    for (const k of keys) {
      value = value?.[k];
    }

    return typeof value === 'string' ? value : key;
  };

  return { language, setLanguage: setLang, t };
}
