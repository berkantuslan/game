import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

type GameType = 'chess' | 'go' | 'shogi' | 'mancala';

interface GameSave {
  id: string;
  game_type: GameType;
  board_state: any;
  current_player: string;
  additional_data: any;
  created_at: string;
  updated_at: string;
}

export function useGameSave(gameType: GameType) {
  const [saves, setSaves] = useState<GameSave[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadSaves = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('game_saves')
        .select('*')
        .eq('game_type', gameType)
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setSaves(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load saves');
    } finally {
      setLoading(false);
    }
  };

  const saveGame = async (
    boardState: any,
    currentPlayer: string,
    additionalData: any = {}
  ): Promise<string | null> => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('game_saves')
        .insert({
          game_type: gameType,
          board_state: boardState,
          current_player: currentPlayer,
          additional_data: additionalData,
        })
        .select()
        .maybeSingle();

      if (error) throw error;
      await loadSaves();
      return data?.id || null;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save game');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const loadGame = async (saveId: string): Promise<GameSave | null> => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('game_saves')
        .select('*')
        .eq('id', saveId)
        .maybeSingle();

      if (error) throw error;
      return data;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load game');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const deleteGame = async (saveId: string): Promise<boolean> => {
    try {
      setLoading(true);
      const { error } = await supabase
        .from('game_saves')
        .delete()
        .eq('id', saveId);

      if (error) throw error;
      await loadSaves();
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete game');
      return false;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSaves();
  }, [gameType]);

  return {
    saves,
    loading,
    error,
    saveGame,
    loadGame,
    deleteGame,
    refreshSaves: loadSaves,
  };
}
