import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { ShogiGame } from '../../lib/shogi/ShogiGame';
import { Piece, Player } from '../../lib/shogi/types';

interface ShogiBoardProps {
  game: ShogiGame;
  selectedSquare: string | null;
  possibleMoves: string[];
  onSquarePress: (square: string) => void;
}

const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'];
const ranks = ['9', '8', '7', '6', '5', '4', '3', '2', '1'];

export default function ShogiBoard({ game, selectedSquare, possibleMoves, onSquarePress }: ShogiBoardProps) {
  const screenWidth = Dimensions.get('window').width;
  const boardSize = Math.min(screenWidth - 40, 400);
  const squareSize = boardSize / 9;

  const renderSquare = (file: string, rank: string) => {
    const square = `${file}${rank}`;
    const piece = game.getPiece(square);
    const isSelected = selectedSquare === square;
    const isPossibleMove = possibleMoves.includes(square);

    return (
      <TouchableOpacity
        key={square}
        style={[
          styles.square,
          { width: squareSize, height: squareSize },
          isSelected && styles.selectedSquare,
          isPossibleMove && styles.possibleMove,
        ]}
        onPress={() => onSquarePress(square)}
      >
        {piece && (
          <Text style={[
            styles.piece,
            { fontSize: squareSize * 0.5 },
            piece.player === 'white' ? styles.whitePiece : styles.blackPiece
          ]}>
            {getPieceSymbol(piece.type, piece.player)}
          </Text>
        )}
      </TouchableOpacity>
    );
  };

  const getPieceSymbol = (type: string, player: Player): string => {
    const symbols: Record<string, string> = {
      king: 'K',
      rook: 'R',
      bishop: 'B',
      gold: 'G',
      silver: 'S',
      knight: 'N',
      lance: 'L',
      pawn: 'P',
      promotedRook: 'R+',
      promotedBishop: 'B+',
      promotedSilver: 'S+',
      promotedKnight: 'N+',
      promotedLance: 'L+',
      promotedPawn: 'P+',
    };
    return symbols[type] || type;
  };

  return (
    <View style={styles.container}>
      <View style={[styles.board, { width: boardSize, height: boardSize }]}>
        {ranks.map((rank) => (
          <View key={rank} style={styles.rank}>
            {files.map((file) => renderSquare(file, rank))}
          </View>
        ))}
      </View>

      <View style={styles.capturedContainer}>
        <View style={styles.capturedSection}>
          <Text style={styles.capturedTitle}>White Captured:</Text>
          <View style={styles.capturedPieces}>
            {game.getCapturedPieces('white').map((piece, index) => (
              <Text key={index} style={styles.capturedPiece}>
                {getPieceSymbol(piece.type, 'black')}
              </Text>
            ))}
          </View>
        </View>
        <View style={styles.capturedSection}>
          <Text style={styles.capturedTitle}>Black Captured:</Text>
          <View style={styles.capturedPieces}>
            {game.getCapturedPieces('black').map((piece, index) => (
              <Text key={index} style={styles.capturedPiece}>
                {getPieceSymbol(piece.type, 'white')}
              </Text>
            ))}
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
  board: {
    backgroundColor: '#daa520',
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#8b4513',
  },
  rank: {
    flexDirection: 'row',
  },
  square: {
    backgroundColor: '#f5deb3',
    borderWidth: 0.5,
    borderColor: '#8b4513',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedSquare: {
    backgroundColor: '#ffd700',
  },
  possibleMove: {
    backgroundColor: '#90ee90',
  },
  piece: {
    fontWeight: 'bold',
  },
  whitePiece: {
    color: '#000',
  },
  blackPiece: {
    color: '#f00',
  },
  capturedContainer: {
    marginTop: 20,
    width: '100%',
  },
  capturedSection: {
    marginBottom: 10,
  },
  capturedTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#374151',
  },
  capturedPieces: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 5,
  },
  capturedPiece: {
    fontSize: 16,
    color: '#1f2937',
  },
});
